#!/bin/bash

content="`cat content.tex | grep -v ^% | grep . | cut -d \{ -f 2 | cut -d \} -f 1`"
appendices="`cat appendices.tex | grep -v ^% | grep . | cut -d \{ -f 2 | cut -d \} -f 1`"

for file in $content $appendices
do
    echo Spellchecking file: $file
    read f
    aspell -c $file.tex
done
