#!/bin/bash

content="`cat content.tex | grep -v ^% | grep . | cut -d \{ -f 2 | cut -d \} -f 1`"
appendices="`cat appendices.tex | grep -v ^% | grep . | cut -d \{ -f 2 | cut -d \} -f 1`"
front="`cat front.tex | grep -v ^% | grep . | cut -d \{ -f 2 | cut -d \} -f 1`"

function stripcomments {
    #sed 's/^%.*$/ /'g | sed 's/[^\]%.*$/ /'g
    sed 's/%.*$/ /'g
}

function stats {
    FILES=$((FILES + 1))

    TEMP_LINES=`cat "$1" | wc -l`
    LINES=$((LINES + TEMP_LINES))

    TEMP_EMPTY_LINES=`cat "$1" | grep -v '[^ \t]' | wc -l`
    EMPTY_LINES=$((EMPTY_LINES + TEMP_EMPTY_LINES))

    TEMP_COMMENT_LINES=`cat "$1" | grep '^%' | wc -l`
    COMMENT_LINES=$((COMMENT_LINES + TEMP_COMMENT_LINES))
 
    TEMP_WORDS=`cat "$1" | stripcomments | wc -w`
    WORDS=$((WORDS + TEMP_WORDS))

    TEMP_SLASHES=`cat "$1" | stripcomments | tr -cd '\\' 2>/dev/null | wc -m`
    SLASHES=$((SLASHES + TEMP_SLASHES))

    TEMP_DOLLARS=`cat "$1" | stripcomments | tr -cd '$' | wc -m`
    DOLLARS=$((DOLLARS + TEMP_DOLLARS))

#     TEMP_OPEN_BRACKETS=`cat "$1" | stripcomments | tr -cd '{' | wc -m`
#     OPEN_BRACKETS=$((OPEN_BRACKETS + TEMP_OPEN_BRACKETS))
#   
#     TEMP_CLOSED_BRACKETS=`cat "$1" | stripcomments | tr -cd '}' | wc -m`
#     CLOSED_BRACKETS=$((CLOSED_BRACKETS + TEMP_CLOSED_BRACKETS))

    #((TEMP_OPEN_BRACKETS != TEMP_CLOSED_BRACKETS)) && echo unbalanced $1

    TEMP_VSPACES=`cat "$1" | stripcomments | grep '\\vspace{' | tr ' ' \n | grep '\\vspace{' | wc -l`
    VSPACES=$((VSPACES + TEMP_VSPACES))

    TEMP_EMPHS=`cat "$1" | stripcomments | grep '\\emph{' | tr ' ' \n | grep '\\emph{' | wc -l`
    EMPHS=$((EMPHS + TEMP_EMPHS))
    
    TEMP_EXPLETIVES=`cat "$1" | grep -iE '(crap|fuck|shit|kurwa)' | wc -l`
    EXPLETIVES=$((EXPLETIVES + TEMP_EXPLETIVES))

    TEMP_CHARS=`cat "$1" | wc -m`
    CHARS=$((CHARS + TEMP_CHARS))
}

function stats_macros {
    FILES=$((FILES + 1))

    TEMP_DEF=`cat "$1" | stripcomments | grep '\\def' | wc -l`
    TEMP_NEWCOMMAND=`cat "$1" | stripcomments | grep '\\newcommand' | wc -l`
    TEMP_RENEWCOMMAND=`cat "$1" | stripcomments | grep '\\renewcommand' | wc -l`
    TEMP_NEWENVIRON=`cat "$1" | stripcomments | grep '\\newenvironment' | wc -l`
    TEMP_RENEWENVIRON=`cat "$1" | stripcomments | grep '\\renewenvironment' | wc -l`
    MACROS=$((MACROS + TEMP_DEF + TEMP_NEWCOMMAND + TEMP_RENEWCOMMAND + TEMP_NEWENVIRON + TEMP_RENEWENVIRON))

}

for file in $content $appendices $front top-csthesis acks
do
    echo Looking at file: $file.tex
    #read f
    #aspell -c $file.tex

    #cat "$file.tex" | grep -v ^% | grep -e '\\input{' | cut -d \{ -f 2 | cut -d \} -f 1
    subcontent="`cat "$file.tex" | grep -v ^% | grep -e '\\input{' | cut -d \{ -f 2 | cut -d \} -f 1`"
    #echo $subcontent
    for subfile in $subcontent
    do
        echo '   ' Looking at subfile: $subfile.tex
        stats "$subfile.tex"
    done
    stats "$file.tex"
done

for file in packages/{hardtitlepage,codeconfig-bw,diarch,diatrans,fm,kbordermatrix,notation,shorthand,transactiondiagram,veralgs}
do
    echo Looking at file: $file.sty
    stats "$file.sty"
    stats_macros "$file.sty"
done   

function prefix {
    :
    #echo -n '\hspace*{1em}'
}

function report {
    echo '\begin{tabular}{ll}%'
    prefix; echo files: $FILES, '&'
            echo characters: $CHARS, '\\'
    prefix; echo words: $WORDS, '&'
            echo dollar signs: $DOLLARS, '\\'
    prefix; echo lines: $LINES, '&'
            echo backslashes: $SLASHES, '\\'
    prefix; echo comment lines: $COMMENT_LINES, '&'
            echo vspaces: $VSPACES, '\\'
    prefix; echo empty lines: $EMPTY_LINES, '&'
            echo macros: $MACROS, '\\'
    prefix; echo emphs: $EMPHS, '&'
    prefix; echo expletives: $EXPLETIVES. '\\'
    echo '\end{tabular}%'

}

report > stats.tex
